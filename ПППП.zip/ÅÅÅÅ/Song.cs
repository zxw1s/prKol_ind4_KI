﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HashTable
{
    internal class Song
    {
        public string disk;
        public string name;
        public string author;

        public Song(string name, string artist, string disk)
        {
            this.name = name;
            this.author = artist;
            this.disk = disk;
        }
    }
}
